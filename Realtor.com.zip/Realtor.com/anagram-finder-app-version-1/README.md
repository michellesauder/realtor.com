# Getting Started with Anagram App

Must have node and npm installed onto machine

### `node anagramFinder.js anagramFinder <word>`

## to exit >> ^C